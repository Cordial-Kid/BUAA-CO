import os
import re

# 当前脚本所在目录
BASE_DIR=os.path.dirname(os.path.abspath(__file__))

# 各文件的绝对路径
mars_jar = "D:\\Mars\\Mars4_5.jar"    # 这里是系统上的绝对路径，不同PC需要自行更改
asm_file = os.path.join(BASE_DIR,"command.asm")
rom_file = os.path.join(BASE_DIR,"command.txt")
circ_file = os.path.join(BASE_DIR,"单周期CPU_after_class.circ")
new_circ_file = os.path.join(BASE_DIR,"remake.circ")   # 备份，防止正则表达式失误导致异更改

# 执行命令
command = f"java -jar {mars_jar} {asm_file} nc mc CompactTextAtZero a dump .text HexText {rom_file}"
os.system(command)

# 读取内容并替换
content = open(rom_file).read()
cur = open(circ_file,encoding="utf-8").read()
cur = re.sub(r'(<a name="contents">addr/data: 12 32)([\s\S]*?)(</a>)',
             r'\1\n'+content+r'\3',
             cur)

# 写入新文件
with open(new_circ_file,"w",encoding="utf-8") as new_file:
    new_file.write(cur)