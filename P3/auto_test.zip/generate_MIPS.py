#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Python 版本：生成类似原 C++ 程序的随机 MIPS 指令文件
# 输出文件：mips_code.txt
import random
import time

# 配置（可按需修改）
size_im = 32      # 指令数量（原程序 size_im=32）
size_dm = 32      # 数据存储大小（原程序 size_dm=32，用于生成基址/偏移计算）
size_op = 8       # 操作种类数（0..7）
small_reg = 8     # 被选为“small”用途的寄存器数量（原程序 small_reg=8）

random.seed(time.time())

# 存放指令的结构（用字典表示）
# type: 0 nop, 1 addu, 2 subu, 3 lui, 4 ori, 5 lw, 6 sw, 7 beq
ops = [None] * (size_im + 1)

# branch_targets: key = 指令位置 i (1..size_im) ，value = list of branch 标签 id 在该位置前要打印
branch_labels_at = {i: [] for i in range(1, size_im + 1)}

# small registers 等相关数组 / map
is_small = {}       # 是否为 small 寄存器的映射
small = [0] * (small_reg + 1)   # 1-based index for easy类比原程序
val = {}            # 基准值 val[reg]（用于 lw/sw 计算）
label_counter = 0   # 分支标签计数器

def pick_reg(a, b, except1):
    """
    返回范围 [a, b] 内的随机寄存器号（整数）。
    如果 except1==1 且生成值为 1，则返回 0（与原程序行为类似）。
    使用 Python 的 random.randint 保证均匀。
    """
    if a > b:
        a, b = b, a
    res = random.randint(a, b)
    if res == 1 and except1 == 1:
        return 0
    return res

def get_small():
    """
    随机选择 small_reg 个寄存器用于 lw/sw 基址寄存器（尽量模拟原程序意图）。
    我们从 [2,27] 范围随机选择 small_reg 个不同寄存器（避开 $1，常留作特殊寄存器）。
    """
    pool = list(range(2, 28))   # 2..27 共 26 个，接近原程序的 t[1..26]
    random.shuffle(pool)
    chosen = pool[:small_reg]
    for i, reg in enumerate(chosen, start=1):
        small[i] = reg
        is_small[reg] = True
        # val 初始化在主程序用 ori 指令指定（这里暂先不设）

get_small()

# 为 first small_reg 条指令生成 ori 以设置寄存器初值（与原 C++ 行为一致）
for i in range(1, small_reg + 1):
    reg = small[i]
    # val[reg] 取 0..size_dm-1（对应原程序 r(0,size_dm-1,0)）
    v = pick_reg(0, size_dm - 1, 0)
    val[reg] = v
    ops[i] = {"type": 4, "r1": reg, "r2": 0, "r3": v}   # ori $reg,$0,v

# 生成剩余指令
for i in range(small_reg + 1, size_im + 1):
    op0 = pick_reg(0, size_op - 1, 0)
    if op0 == 0:
        ops[i] = {"type": 0}
    elif op0 in (1, 2):  # addu / subu
        r1 = None
        # nosmall(): 随机产生一个不在 small[] 中的寄存器
        while True:
            r1cand = pick_reg(0, 27, 1)
            if not is_small.get(r1cand, False):
                r1 = r1cand
                break
        ops[i] = {"type": op0, "r1": r1, "r2": pick_reg(0, 27, 1), "r3": pick_reg(0, 27, 1)}
    elif op0 in (3, 4):  # lui / ori
        r1 = None
        while True:
            r1cand = pick_reg(0, 27, 1)
            if not is_small.get(r1cand, False):
                r1 = r1cand
                break
        imm = pick_reg(0, 65535, 0)
        ops[i] = {"type": op0, "r1": r1, "r2": pick_reg(0, 27, 1), "r3": imm}
    elif op0 == 5:  # lw
        r1 = pick_reg(0, size_dm - 1, 0)
        r2_i = pick_reg(1, small_reg, 0)  # index into small[]
        base_reg = small[r2_i]
        # r1 is a memory index (word index). compute byte offset as (r1 - val[base])*4
        base_val = val.get(base_reg, 0)
        offset = (r1 - base_val) * 4
        # destination reg should not be small
        dst = None
        while True:
            dst_cand = pick_reg(0, 27, 1)
            if not is_small.get(dst_cand, False):
                dst = dst_cand
                break
        ops[i] = {"type": 5, "r1": dst, "r2": base_reg, "r3": offset}
    elif op0 == 6:  # sw
        r1 = pick_reg(0, size_dm - 1, 0)
        r2_i = pick_reg(1, small_reg, 0)
        base_reg = small[r2_i]
        base_val = val.get(base_reg, 0)
        offset = (r1 - base_val) * 4
        src = pick_reg(0, 27, 1)
        ops[i] = {"type": 6, "r1": src, "r2": base_reg, "r3": offset}
    elif op0 == 7:  # beq
        # 在原代码中，r3 = r(i, size_im, 0) 作为目标位置索引，
        # 并把 ++cnt 放入 op.r3，且 branch[target_index].push_back(cnt)
        target_idx = random.randint(i, size_im)
        if (False):
            label_counter += 1
         # placeholder to avoid UnboundLocal in next block
        # We'll increment label_counter from outer scope properly:
        # (Python scoping: we need to use global to modify)
        # So fix: handle labels with explicit global increment below
        # (See after loop)
        # To avoid complicated scoping inside loop, collect beq entries in a temp list and process after loop

# --- Above loop left early to handle label counter scoping nicely. Rebuild loop with label handling properly. ---

# Reset and regenerate to properly manage label_counter
ops = [None] * (size_im + 1)
branch_labels_at = {i: [] for i in range(1, size_im + 1)}
label_counter = 0
# Recreate small, val, initial ori part reproducibly (do not reshuffle small selection)
# We'll reuse small, is_small, val from earlier get_small() and initial ori assignment
# Re-generate first ori instructions
for i in range(1, small_reg + 1):
    reg = small[i]
    # val[reg] already set above; if not, set now
    if reg not in val:
        val[reg] = pick_reg(0, size_dm - 1, 0)
    ops[i] = {"type": 4, "r1": reg, "r2": 0, "r3": val[reg]}

# Now generate remaining with proper label handling
for i in range(small_reg + 1, size_im + 1):
    op0 = pick_reg(0, size_op - 1, 0)
    if op0 == 0:
        ops[i] = {"type": 0}
    elif op0 in (1, 2):  # addu / subu
        # nosmall
        r1 = None
        while True:
            r1cand = pick_reg(0, 27, 1)
            if not is_small.get(r1cand, False):
                r1 = r1cand
                break
        ops[i] = {"type": op0, "r1": r1, "r2": pick_reg(0, 27, 1), "r3": pick_reg(0, 27, 1)}
    elif op0 in (3, 4):  # lui / ori
        r1 = None
        while True:
            r1cand = pick_reg(0, 27, 1)
            if not is_small.get(r1cand, False):
                r1 = r1cand
                break
        imm = pick_reg(0, 65535, 0)
        ops[i] = {"type": op0, "r1": r1, "r2": pick_reg(0, 27, 1), "r3": imm}
    elif op0 == 5:  # lw
        r1 = pick_reg(0, size_dm - 1, 0)
        r2_i = pick_reg(1, small_reg, 0)
        base_reg = small[r2_i]
        base_val = val.get(base_reg, 0)
        offset = (r1 - base_val) * 4
        dst = None
        while True:
            dst_cand = pick_reg(0, 27, 1)
            if not is_small.get(dst_cand, False):
                dst = dst_cand
                break
        ops[i] = {"type": 5, "r1": dst, "r2": base_reg, "r3": offset}
    elif op0 == 6:  # sw
        r1 = pick_reg(0, size_dm - 1, 0)
        r2_i = pick_reg(1, small_reg, 0)
        base_reg = small[r2_i]
        base_val = val.get(base_reg, 0)
        offset = (r1 - base_val) * 4
        src = pick_reg(0, 27, 1)
        ops[i] = {"type": 6, "r1": src, "r2": base_reg, "r3": offset}
    elif op0 == 7:  # beq
        target_idx = random.randint(i, size_im)
        label_counter += 1
        label_id = label_counter
        # create beq with label id in r3 (to mimic original's ++cnt stored in op.r3)
        ops[i] = {"type": 7, "r1": pick_reg(0, 27, 1), "r2": pick_reg(0, 27, 1), "r3": label_id}
        # note: we record that branch label 'label_id' should be printed at instruction index target_idx
        branch_labels_at[target_idx].append(label_id)

# 输出到文件
def print_inst(f, idx):
    ins = ops[idx]
    if ins is None:
        f.write("nop\n")
        return
    t = ins["type"]
    if t == 0:
        f.write("nop\n")
    elif t == 1:
        f.write(f"addu ${ins['r1']},${ins['r2']},${ins['r3']}\n")
    elif t == 2:
        f.write(f"subu ${ins['r1']},${ins['r2']},${ins['r3']}\n")
    elif t == 3:
        f.write(f"lui ${ins['r1']},{ins['r3']}\n")
    elif t == 4:
        f.write(f"ori ${ins['r1']},${ins['r2']},{ins['r3']}\n")
    elif t == 5:
        f.write(f"lw ${ins['r1']},{ins['r3']}(${ins['r2']})\n")
    elif t == 6:
        f.write(f"sw ${ins['r1']},{ins['r3']}(${ins['r2']})\n")
    elif t == 7:
        f.write(f"beq ${ins['r1']},${ins['r2']},branch{ins['r3']}\n")
    else:
        f.write("nop\n")

with open("command.asm", "w", encoding="utf-8") as fout:
    for i in range(1, size_im + 1):
        print_inst(fout, i)
        # print any branch labels that should appear at this location (same style as原程序)
        for lbl in branch_labels_at.get(i, []):
            fout.write(f"branch{lbl}:\n")

print("生成完成 -> mips_code.txt")
