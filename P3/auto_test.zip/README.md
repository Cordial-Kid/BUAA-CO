1. generate_MIPS.py 生成MIPS指令，形成command.asm
2. update_ROM生成将command.asm的指令导出成为16进制文件存入logisim的ROM
3. 用户运行logisim并导出RAM的数据
4. compare.py比较logisim导出数据和MIPS导出data是否相等(只比较前3072行)、

PS：generate_MIPS.py为AI生成