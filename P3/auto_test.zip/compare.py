def compare_files_line_by_line(file1,file2,maxlen = 3072):
    with open(file1,"r",encoding="utf-8") as f1,open(file2,"r",encoding="utf-8") as f2:
        lines1 = f1.readlines()[:maxlen]
        lines2 = f2.readlines()[:maxlen]   # 读取所有行得到的是列表，并切片

    same = True
    for i ,(l1,l2) in enumerate(zip(lines1,lines2),start=1):
        if l1.strip() != l2.strip():
            print(f"第{i}行不同")
            same = False
    if same:
        print(f"all the same")

if __name__ == "__main__":
    compare_files_line_by_line("std_ans.txt","ans.txt")